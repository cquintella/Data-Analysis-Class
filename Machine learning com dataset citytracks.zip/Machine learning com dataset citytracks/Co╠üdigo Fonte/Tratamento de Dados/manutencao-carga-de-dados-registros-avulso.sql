
USE prod_tracks;
delimiter $$
CREATE Temporary TABLE `tmpTraces` (
  `device_id` varchar(32) NOT NULL,
  `measurement_timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `course` float(10,6) DEFAULT NULL,
  `altitude` float(7,2) DEFAULT NULL,
  `speed` float(10,6) DEFAULT NULL,
  `vertical_accuracy` float(10,6) DEFAULT NULL,
  `horizontal_accuracy` float(10,6) DEFAULT NULL,
  `latitude` float(10,6) DEFAULT NULL,
  `longitude` float(10,6) DEFAULT NULL
);
$$ 
CREATE Temporary TABLE `tmpNotes` (
  `device_id` varchar(32) NOT NULL,
  `measurement_timestamp` datetime NOT NULL,
  `course` float(10,6) DEFAULT NULL,
  `altitude` float(10,6) DEFAULT NULL,
  `speed` float(10,6) DEFAULT NULL,
  `vertical_accuracy` float(10,6) DEFAULT NULL,
  `horizontal_accuracy` float(10,6) DEFAULT NULL,
  `latitude` float(10,6) DEFAULT NULL,
  `longitude` float(10,6) DEFAULT NULL,
  `note_title` varchar(60) DEFAULT NULL,
  `note_subject` varchar(255) DEFAULT NULL
);
$$
LOAD DATA LOCAL INFILE '/Users/caq/1notes.csv' INTO TABLE note
  FIELDS TERMINATED BY ',' ENCLOSED BY '"'
  #LINES TERMINATED BY '\r\n'
  IGNORE 1 LINES;
$$
SELECT * FROM tmpNotes;
$$
LOAD DATA LOCAL INFILE '/Users/caq/1traces.csv' INTO TABLE location_traces
  FIELDS TERMINATED BY ',' ENCLOSED BY '"'
  #LINES TERMINATED BY '\r\n'
  IGNORE 1 LINES;
$$
SELECT * FROM tmpTraces;