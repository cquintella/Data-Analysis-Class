
delimiter $$

-- Apaga a tabela temporária para preparar a nova carga de dados.

drop TABLE tmpTable;
$$
drop TABLE tmpNote;
$$

-- Cria a tabela temporária para a carga de dados.
CREATE Temporary TABLE `tmpTable` (
  `device_id` varchar(32) NOT NULL,
  `measurement_timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `course` float(10,6) DEFAULT NULL,
  `altitude` float(7,2) DEFAULT NULL,
  `speed` float(10,6) DEFAULT NULL,
  `vertical_accuracy` float(10,6) DEFAULT NULL,
  `horizontal_accuracy` float(10,6) DEFAULT NULL,
  `latitude` float(10,6) DEFAULT NULL,
  `longitude` float(10,6) DEFAULT NULL
);
$$
-- Para os registros que tem repetidos, carrega apenas os que possuem o melhor horizontal accuracy dos repetidos.
INSERT INTO tmpTable 
SELECT device_id, measurement_timestamp, course, altitude, speed, vertical_accuracy, horizontal_accuracy, latitude, longitude
FROM prod_tracks.location_traces
WHERE horizontal_accuracy>-1 
#AND measurement_timestamp > '2012-12-05 00:00:00'
GROUP BY device_id, measurement_timestamp 
HAVING count(*)>1 AND MIN(HORIZONTAL_ACCURACY)
;
$$
-- Carrega os registros que não tem repetidos
INSERT INTO tmpTable 
SELECT device_id, measurement_timestamp, course, altitude, speed, vertical_accuracy, horizontal_accuracy, latitude, longitude
FROM prod_tracks.location_traces
# WHERE measurement_timestamp > '2012-12-05 00:00:00'
GROUP BY device_id, measurement_timestamp
HAVING count(*)=1;
$$

delimiter $$
drop table `prod_tracks`.`location_traces`;
$$

CREATE TABLE `fixed_traces` (
  `device` varchar(32) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `course` float(10,6) DEFAULT NULL,
  `altitude` float(7,2) DEFAULT NULL,
  `speed` float(10,6) DEFAULT NULL,
  `vertical_accuracy` float(10,6) DEFAULT NULL,
  `horizontal_accuracy` float(10,6) DEFAULT NULL,
  `latitude` float(10,6) DEFAULT NULL,
  `longitude` float(10,6) DEFAULT NULL,
  PRIMARY KEY (`device`,`time`)
) ENGINE=InnoDB 

$$
-- Insere o conteúdo da tabela temporária na tabela fixed traces
INSERT INTO prod_tracks.fixed_traces
SELECT device_id as device, measurement_timestamp as time, course, altitude, speed, vertical_accuracy, horizontal_accuracy, latitude, longitude
FROM tmpTable
ORDER BY device, time;
$$
COMMIT;
$$